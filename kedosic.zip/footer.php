<section class="site-footer">
    <div class="footer-top">
        <div class="row1">
            <a href="./">
                <img src="assets/images/icons/kedosic.svg" class="site-logo" alt="">
            </a>
            <p>
                Kedosic innovation was founded in 2020 by Kpenuoguoreata & Oluchi Olafonye with the goat to support
                the most talented and ambitious entreprenuers build a company
            </p>
            <p class="copy-right">2020 Kedosic. All Right Reserved</p>
        </div>
        <div class="row2">
            <ul>
                <li class="title">Explore</li>
                <li><a href="">How it works</a></li>
                <li><a href="">Who we are</a></li>
                <li><a href="">Contact Us</a></li>
                <li><a href="">Blog</a></li>
            </ul>
        </div>
        <div class="row3">
            <div class="title">Visit</div>
            <p>Elzazi complex, Opposite westharm petrol station along gpalagam/Akpajam, woji (Odili Road, Port-Harcourt)</p>
        </div>
        <div class="row4">
            <ul>
                <li class="title">Explore</li>
                <li><a href="">Terms and Condition</a></li>
                <li><a href="">Privacy Policy</a></li>
                <div class="icons-container">
                    <button class="icon"><i class="fa fa-instagram"></i></button>
                    <button class="icon"><i class="fa fa-twitter"></i></button>
                    <button class="icon"><i class="fa fa-facebook"></i></button>
                </div>

            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        Built with <i class="fa fa-heart"></i> By <a href="">Harvoxx Tech Hub</a>
    </div>
</section>